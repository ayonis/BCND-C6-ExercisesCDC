var ExerciseC6D = artifacts.require('./ExerciseC6D.sol');
module.exports = function(deployer) {
    deployer.deploy(ExerciseC6D);
};