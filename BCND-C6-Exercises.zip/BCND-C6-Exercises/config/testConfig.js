
var ExerciseC6D = artifacts.require("ExerciseC6D");

var Config = async function(accounts) {
    
    // These test addresses are useful when you need to add
    // multiple users in test scripts
    let testAddresses = [
        "0x06620d0cacc34707b3dbe3d8114f1970c3f98078",
        "0xcbf86de93b279f0f8167f4c945d5bcfa394a6312",
        "0x3142b2b6a9b4137ac62d41179a5bbff06f48684f",
        "0x50b1beb53f01fde6f46ebd0dc2431b60a2e888e0",

    ];


    let owner = accounts[0];
    let exerciseC6D = await ExerciseC6D.new();
    
    return {
        owner: owner,
        testAddresses: testAddresses,
        exerciseC6D: exerciseC6D
    }
}

module.exports = {
    Config: Config
};